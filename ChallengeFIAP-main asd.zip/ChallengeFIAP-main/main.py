import os
import time
import getpass
import atexit
from threading import Thread
import platform
from modules.UserManagement import UserManagement
from modules.MalwareControl import MalwareControl
from modules.FilesManagement import FilesManagement  # Certifique-se de que essa importação está correta


# Função para obter o caminho da pasta Downloads baseado no sistema operacional
def get_downloads_path():
    user = getpass.getuser()
    system = platform.system()

    if system == "Windows":
        return os.path.join('C:\\Users', user, 'Downloads')
    elif system in ["Linux", "Darwin"]:  # Linux e macOS
        return os.path.join('/home', user, 'Downloads') if os.path.exists(
            '/home/' + user + '/Downloads') else '/root/Downloads'
    else:
        raise NotImplementedError(f"Unsupported OS: {system}")


class Main:
    def __init__(self) -> None:
        os.environ['FIAP'] = str(1)
        self.MalwareControl = MalwareControl()
        atexit.register(self.stop)

        # Inicia a thread principal para executar o método start
        mainThread = Thread(target=self.start)
        mainThread.start()

    def start(self):
        # Carrega as regras YARA
        self.MalwareControl.loadYaraRules()

        # Obtém o caminho da pasta Downloads
        downloads_path = get_downloads_path()

        # Verifica se o diretório existe antes de tentar monitorar
        if not os.path.exists(downloads_path):
            raise FileNotFoundError(f"Directory {downloads_path} does not exist")

        # Monitora o diretório de downloads
        FilesManagement.monitor_downloads(downloads_path, self.MalwareControl.matchYara)

        # Loop para verificar a variável de ambiente e monitorar usuários e shells
        while int(os.getenv('FIAP', '0')):
            # Executa o código fornecido
            remote_ips = UserManagement.getRemoteUsersIP()
            if remote_ips:
                print(f"IPs remotos encontrados: {remote_ips}")
            else:
                print("Sem conexão remota")

            if UserManagement.checkShellProcesses():
                print("Há shells em execução.")
            else:
                print("Nenhuma shell em execução.")

            # Verifica e monitora usuários
            self.monitor_users()

            # Aguarda 60 segundos antes de repetir
            time.sleep(60)

    def monitor_users(self):
        current_users = UserManagement.get_users()
        time.sleep(60)  # Espera para permitir que novos usuários sejam adicionados
        updated_users = UserManagement.get_users()
        new_users = updated_users - current_users
        if new_users:
            print("Novos usuários detectados:")
            for user in new_users:
                print(f'Novo usuário criado: {user}')
        else:
            print("Nenhum novo usuário detectado.")

    def stop(self):
        compiledRulesPath = 'database/bin'
        if os.path.isfile(compiledRulesPath):
            os.remove(compiledRulesPath)


# Cria uma instância da classe Main se o script for executado diretamente
if __name__ == "__main__":
    Main()
