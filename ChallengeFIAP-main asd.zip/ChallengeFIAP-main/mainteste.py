import subprocess
import platform
import time


class UserManagement:

    @staticmethod
    def getRemoteUsersIP() -> list[str]:
        system = platform.system()

        if system == "Windows":
            command = "netstat -an | findstr :"
            try:
                result = subprocess.check_output(command, shell=True, text=True)
                ip_list = set()
                for line in result.strip().split('\n'):
                    if 'ESTABLISHED' in line:
                        ip = line.split()[1].split(':')[0]
                        ip_list.add(ip)
                return list(ip_list)
            except subprocess.CalledProcessError as e:
                print("Erro ao executar o comando: ", e)
                return []

        elif system in ["Linux", "Darwin"]:  # Linux e macOS
            command = "ss -tn | awk 'NR > 1 {print $5}' | cut -d':' -f1 | sort | uniq" if system == "Linux" else "ifconfig"
            try:
                result = subprocess.check_output(command, shell=True, text=True)
                ip_list = [ip for ip in result.strip().split('\n') if ip]
                return ip_list
            except subprocess.CalledProcessError as e:
                print("Erro ao executar o comando: ", e)
                return []

        else:
            raise NotImplementedError(f"Unsupported OS: {system}")

    @staticmethod
    def checkShellProcesses() -> bool:
        system = platform.system()

        if system == "Windows":
            command = "tasklist | findstr /i \"cmd.exe\""
            try:
                result = subprocess.check_output(command, shell=True, text=True)
                return 'cmd.exe' in result
            except subprocess.CalledProcessError as e:
                print("Erro ao executar o comando: ", e)
                return False

        elif system in ["Linux", "Darwin"]:  # Linux e macOS
            command = "ps -eo comm | grep -E 'bash|zsh|sh|fish'"
            try:
                result = subprocess.check_output(command, shell=True, text=True)
                return bool(result.strip())
            except subprocess.CalledProcessError as e:
                print("Erro ao executar o comando: ", e)
                return False

        else:
            raise NotImplementedError(f"Unsupported OS: {system}")

    @staticmethod
    def get_users() -> set[str]:
        system = platform.system()

        if system == "Darwin":  # macOS
            result = subprocess.run(['dscl', '.', 'list', '/Users'], capture_output=True, text=True)
            return set(result.stdout.splitlines())

        elif system == "Linux":  # Linux
            result = subprocess.run(['cut', '-d:', '-f1', '/etc/passwd'], capture_output=True, text=True)
            return set(result.stdout.splitlines())

        else:
            raise NotImplementedError(f"Unsupported OS for user listing: {system}")

    @staticmethod
    def write_alert(new_user: str):
        with open('user_alert.txt', 'a') as file:
            file.write(f'Novo usuário criado: {new_user}\n')

    @staticmethod
    def monitor_users():
        current_users = UserManagement.get_users()
        time.sleep(10)  # Espera para permitir que novos usuários sejam adicionados
        updated_users = UserManagement.get_users()
        new_users = updated_users - current_users
        if new_users:
            print("Novos usuários detectados:")
            for user in new_users:
                print(f'Novo usuário criado: {user}')
                UserManagement.write_alert(user)
        else:
            print("Nenhum novo usuário detectado.")


# Teste
if __name__ == "__main__":
    remote_ips = UserManagement.getRemoteUsersIP()
    if remote_ips:
        print("IPs remotos encontrados:", remote_ips)
    else:
        print("Sem conexão remota")

    if UserManagement.checkShellProcesses():
        print("Há shells em execução.")
    else:
        print("Nenhuma shell em execução.")

    UserManagement.monitor_users()
