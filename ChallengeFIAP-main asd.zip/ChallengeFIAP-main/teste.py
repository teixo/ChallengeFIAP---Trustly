# Supondo que você já tenha uma instância de MalwareControl
malware_control = MalwareControl()
malware_control.loadYaraRules()

# Caminho para o arquivo EICAR para teste
eicar_path = '/path/to/eicar_test_file.txt'
malware_control.matchYara(eicar_path)
