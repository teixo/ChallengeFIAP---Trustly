import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


class FilesManagement:
    class FileHandler(FileSystemEventHandler):
        def __init__(self, callback):
            super().__init__()
            self.files = set()
            self.callback = callback

        def on_created(self, event):
            if not event.is_directory:
                print(f"New file detected: {event.src_path}")
                self.files.add(event.src_path)
                if self.callback:
                    self.callback(event.src_path)

    @staticmethod
    def monitor_downloads(directory_to_watch, callback):
        event_handler = FilesManagement.FileHandler(callback)
        observer = Observer()
        observer.schedule(event_handler, directory_to_watch, recursive=False)
        observer.start()
        
        try:
            while True:
                time.sleep(1) 
        except KeyboardInterrupt:
            observer.stop()
        
        observer.join()




