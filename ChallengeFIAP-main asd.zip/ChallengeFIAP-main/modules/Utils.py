import os, glob


class Utils:
    @staticmethod
    def list_files(directory) -> list[str]:
        files = []
        for entry in os.listdir(directory):
            full_path = os.path.join(directory, entry)
            files.append(full_path)
        return files
